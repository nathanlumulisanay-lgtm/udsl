We should fix the problems with compliance because it's messy now.

Background info: The teams don't follow the rules well. Things go wrong often.

My recommendation is to improve things as soon as possible.

(This memo has no structure, no reasoning model, missing sections, unclear tone, and violates UDSL format.)
